#include "LTgame.hpp"
using namespace std;
signed main(){
	playgame();
	return 0;
}
